package com.mycompany.testy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
